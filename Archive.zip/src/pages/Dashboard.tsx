import React from "react";
import Home from "../features/home/Home";

const Dashboard = () => {
  return <Home />;
};

export default Dashboard;
