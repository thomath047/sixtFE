export enum APIStatus {
    idle = 'idle',
    loading = 'loading',
    failed = 'failed',
    success = 'success',
}
