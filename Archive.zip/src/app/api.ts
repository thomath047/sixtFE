import axios from 'axios';

export const DEVICE_HOST = 'cdn.sixt.io/codingtask/';
export const apiClient = axios.create({
    baseURL: `https://${DEVICE_HOST}`,
});
