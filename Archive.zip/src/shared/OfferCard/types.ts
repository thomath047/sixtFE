export type Props = {
    data: CarDetails,
}
type CarDetails = {
    carGroupInfo: any,
    prices: Object,
}