import styled from 'styled-components'

export const CardWrapper = styled.div`
    position: relative;
    flex-basis: calc(25% - 20px);
    margin: 10px;
    background-color: red;
    box-sizing: border-box;

    @media (max-width: 1024px) {
        flex-basis: calc(33.3% - 20px);
    }

    @media (max-width: 768px) {
        flex-basis: calc(50% - 20px);
    }

    &::before {
        content: '';
        display: block;
        padding-top: 100%;
    }
`

export const CardContent = styled.div`
    position: absolute;
    top: 0; left: 0;
    height: 100%;
    width: 100%;
    background-image: linear-gradient(to bottom, transparent 40%, rgba(0,0,0,0.5) 60%);
`

export const Img = styled.img`
    width: 100%;
    height: 100%;
    object-fit: cover;
`

export const H1 = styled.h1`
    color: white;
`
export const P = styled.p`
   color: white;
`