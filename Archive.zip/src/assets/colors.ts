export const colors = {
    themeColor: '#ff5f00',
    themeBlack: '#191919',
}